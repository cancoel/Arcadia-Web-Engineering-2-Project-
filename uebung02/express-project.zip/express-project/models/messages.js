'use strict';

var mongoose = require("mongoose");


var UserMessage = new mongoose.Schema({
    user: { "type": mongoose.Schema.ObjectId, "ref": "User" },
    username: String,
    view: {
        inbox: Boolean,
        outbox: Boolean,
        archive: Boolean
    },
    content: {type: String},
    read: {
        marked: { "type": Boolean, default: false },
        date: Date
    }
});

var schemaMessage = new mongoose.Schema.ObjectId({
    from: String,
    to: [UserMessage],
    message: String,
    created: Date
});

module.exports = mongoose.model("Messages", UserMessage);
